@echo off
REM Zelda3 Texture Tool - opens the texture viewer/editor in your browser.
cd /d "%~dp0.."
if exist "assets\python.exe" (
  "assets\python.exe" "texture_tool\zelda3_texture_tool.py" %*
) else (
  python "texture_tool\zelda3_texture_tool.py" %*
)
if errorlevel 1 pause
