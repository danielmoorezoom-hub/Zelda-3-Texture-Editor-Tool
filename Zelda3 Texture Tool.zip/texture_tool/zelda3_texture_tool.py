#!/usr/bin/env python3
"""
Zelda3 Texture Tool
===================
View, export and import the graphics stored in zelda3_assets.dat (snesrev/zelda3)
and in Link .zspr sprite files.

Usage (from the game folder):
  assets\\python.exe texture_tool\\zelda3_texture_tool.py            -> opens the browser UI
  ... zelda3_texture_tool.py list
  ... zelda3_texture_tool.py export-all  [DIR]      (default DIR: texture_tool/export)
  ... zelda3_texture_tool.py import-all  [DIR]      (imports changed PNGs and saves)
  ... zelda3_texture_tool.py export ID OUT.png [--palette N]
  ... zelda3_texture_tool.py import ID IN.png      (imports and saves)
  Global option: --game DIR   (folder containing zelda3_assets.dat; default: parent of this script)

Only needs Python 3 + Pillow (the embedded Python in the game's assets folder already has both).
"""
import array
import base64
import io
import json
import os
import re
import shutil
import struct
import sys
import threading
import time
import urllib.parse
import urllib.request

try:
    from PIL import Image, PngImagePlugin
except ImportError:  # pragma: no cover
    print("Pillow is required:  python -m pip install pillow")
    sys.exit(1)

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
TOOL_VERSION = "1.1"
DEFAULT_PORT = 47823

# ----------------------------------------------------------------------------
# zelda3_assets.dat container
# ----------------------------------------------------------------------------
# Layout (see src/main.c LoadAssets and assets/compile_resources.py):
#   48 bytes signature ("Zelda3_v0     \n\0" + sha256 of the key names)
#   32 bytes zero
#   uint32 count, uint32 keys_len
#   uint32 sizes[count]
#   keys: NUL-terminated names
#   data blobs, each aligned to 4 bytes


class AssetFile:
    def __init__(self, path):
        self.path = path
        data = open(path, "rb").read()
        if not data.startswith(b"Zelda3_v0"):
            raise ValueError("%s is not a zelda3 asset file" % path)
        self.header = data[:80]
        n, klen = struct.unpack_from("<II", data, 80)
        sizes = struct.unpack_from("<%dI" % n, data, 88)
        self.key_blob = data[88 + 4 * n: 88 + 4 * n + klen]
        keys = [k.decode() for k in self.key_blob.split(b"\0")[:-1]]
        if len(keys) != n:
            raise ValueError("asset key table is corrupt")
        off = 88 + 4 * n + klen
        self.names = keys
        self.blobs = {}
        for k, s in zip(keys, sizes):
            off = (off + 3) & ~3
            self.blobs[k] = bytes(data[off: off + s])
            off += s

    def get(self, name):
        return self.blobs[name]

    def set(self, name, value):
        assert name in self.blobs
        self.blobs[name] = bytes(value)

    def serialize(self):
        n = len(self.names)
        out = bytearray(self.header)
        out += struct.pack("<II", n, len(self.key_blob))
        out += struct.pack("<%dI" % n, *[len(self.blobs[k]) for k in self.names])
        out += self.key_blob
        for k in self.names:
            while len(out) & 3:
                out.append(0)
            out += self.blobs[k]
        return bytes(out)


def unpack_array(b):
    """Inverse of compile_resources.pack_arrays (C: FindIndexInMemblk)."""
    if len(b) < 2:
        return []
    end = len(b) - 2
    mx = struct.unpack_from("<H", b, end)[0]
    w, fmt = 2, "H"
    if mx >= 8192:
        mx -= 8192
        w, fmt = 4, "I"
    offs = [0] + list(struct.unpack_from("<%d%s" % (mx, fmt), b, 0)) + [end - mx * w]
    base = mx * w
    return [bytes(b[base + offs[i]: base + offs[i + 1]]) for i in range(mx + 1)]


def pack_array(arr):
    if not arr:
        return b""
    all_offs, offs = [], 0
    for a in arr[:-1]:
        offs += len(a)
        all_offs.append(offs)
    if offs < 65536 and len(arr) <= 8192:
        return b"".join([struct.pack("<H", i) for i in all_offs] + list(arr) + [struct.pack("<H", len(arr) - 1)])
    return b"".join([struct.pack("<I", i) for i in all_offs] + list(arr) + [struct.pack("<H", 8192 + len(arr) - 1)])


# ----------------------------------------------------------------------------
# ALttP LZ compression (C: Decompress in src/load_gfx.c)
# ----------------------------------------------------------------------------

def decompress(src):
    dst = bytearray()
    p = 0
    while True:
        c = src[p]
        p += 1
        if c == 0xFF:
            return bytes(dst)
        if (c & 0xE0) != 0xE0:
            l = (c & 0x1F) + 1
            cmd = c & 0xE0
        else:
            l = src[p] + ((c & 3) << 8) + 1
            p += 1
            cmd = (c << 3) & 0xE0
        if cmd == 0:
            dst += src[p: p + l]
            p += l
        elif cmd & 0x80:
            o = src[p] | src[p + 1] << 8
            p += 2
            for _ in range(l):
                dst.append(dst[o])
                o += 1
        elif not cmd & 0x40:
            dst += bytes([src[p]]) * l
            p += 1
        elif not cmd & 0x20:
            lo, hi = src[p], src[p + 1]
            p += 2
            for i in range(l):
                dst.append(lo if i % 2 == 0 else hi)
        else:
            v = src[p]
            p += 1
            for i in range(l):
                dst.append((v + i) & 0xFF)


def _emit(out, cmd, length, payload):
    # cmd: 0=literal 1=memset 2=memset16 3=incr 4=copy
    n = length - 1
    if n < 32:
        out.append((cmd << 5) | n)
    else:
        out.append(0xE0 | (cmd << 2) | (n >> 8))
        out.append(n & 0xFF)
    out += payload


def compress(data):
    """Greedy compressor producing the format the game's Decompress() reads."""
    data = bytes(data)
    n = len(data)
    out = bytearray()
    lit = bytearray()
    index = {}  # 3-byte prefix -> list of positions
    MAXL = 1024

    def flush():
        i = 0
        while i < len(lit):
            chunk = lit[i: i + MAXL]
            _emit(out, 0, len(chunk), chunk)
            i += MAXL
        lit.clear()

    def add_index(pos):
        if pos + 3 <= n:
            index.setdefault(data[pos: pos + 3], []).append(pos)

    p = 0
    while p < n:
        best = (0, None, b"")  # (length, cmd, payload)
        # memset
        l = 1
        while p + l < n and l < MAXL and data[p + l] == data[p]:
            l += 1
        if l > best[0]:
            best = (l, 1, bytes([data[p]]))
        # memset16
        if p + 1 < n:
            l = 2
            while p + l < n and l < MAXL and data[p + l] == data[p + (l & 1)]:
                l += 1
            if l > best[0] + 1:
                best = (l, 2, data[p: p + 2])
        # incrementing
        l = 1
        while p + l < n and l < MAXL and data[p + l] == ((data[p] + l) & 0xFF):
            l += 1
        if l > best[0]:
            best = (l, 3, bytes([data[p]]))
        # back-reference copy (absolute offset into output)
        if p + 3 <= n:
            for cand in reversed(index.get(data[p: p + 3], [])[-64:]):
                l = 0
                while p + l < n and l < MAXL and data[cand + l] == data[p + l]:
                    l += 1
                if l > best[0] + 1:
                    best = (l, 4, struct.pack("<H", cand))
        length, cmd, payload = best
        threshold = {1: 3, 2: 4, 3: 3, 4: 4}.get(cmd, 99)
        if cmd is not None and length >= threshold:
            flush()
            _emit(out, cmd, length, payload)
            for q in range(p, p + length):
                add_index(q)
            p += length
        else:
            lit.append(data[p])
            add_index(p)
            p += 1
    flush()
    out.append(0xFF)
    assert decompress(out) == data, "compressor self-check failed"
    return bytes(out)


# ----------------------------------------------------------------------------
# SNES tile codecs. Pixel buffers are bytearrays of palette indices, row-major.
# ----------------------------------------------------------------------------

def decode_tiles(data, bpp, width, height):
    tw = width // 8
    ntiles = (width // 8) * (height // 8)
    out = bytearray(width * height)
    tsize = 8 * bpp
    for t in range(ntiles):
        base = t * tsize
        ox, oy = (t % tw) * 8, (t // tw) * 8
        for y in range(8):
            if bpp == 2:
                planes = (data[base + y * 2], data[base + y * 2 + 1])
            elif bpp == 3:
                planes = (data[base + y * 2], data[base + y * 2 + 1], data[base + 16 + y])
            elif bpp == 4:
                planes = (data[base + y * 2], data[base + y * 2 + 1],
                          data[base + 16 + y * 2], data[base + 17 + y * 2])
            row = (oy + y) * width + ox
            for x in range(8):
                bit = 7 - x
                v = 0
                for pi, pl in enumerate(planes):
                    v |= ((pl >> bit) & 1) << pi
                out[row + x] = v
    return out


def encode_tiles(pixels, bpp, width, height):
    tw = width // 8
    ntiles = (width // 8) * (height // 8)
    tsize = 8 * bpp
    out = bytearray(ntiles * tsize)
    for t in range(ntiles):
        base = t * tsize
        ox, oy = (t % tw) * 8, (t // tw) * 8
        for y in range(8):
            planes = [0] * bpp
            row = (oy + y) * width + ox
            for x in range(8):
                v = pixels[row + x]
                for pi in range(bpp):
                    planes[pi] |= ((v >> pi) & 1) << (7 - x)
            if bpp == 2:
                out[base + y * 2], out[base + y * 2 + 1] = planes
            elif bpp == 3:
                out[base + y * 2], out[base + y * 2 + 1], out[base + 16 + y] = planes
            elif bpp == 4:
                (out[base + y * 2], out[base + y * 2 + 1],
                 out[base + 16 + y * 2], out[base + 17 + y * 2]) = planes
    return out


def decode_mode7(data):
    # 256 chars of 8x8, 1 byte/pixel, linear -> 128x128 image (16x16 chars)
    out = bytearray(128 * 128)
    for t in range(256):
        ox, oy = (t % 16) * 8, (t // 16) * 8
        for y in range(8):
            out[(oy + y) * 128 + ox: (oy + y) * 128 + ox + 8] = data[t * 64 + y * 8: t * 64 + y * 8 + 8]
    return out


def encode_mode7(pixels):
    out = bytearray(0x4000)
    for t in range(256):
        ox, oy = (t % 16) * 8, (t // 16) * 8
        for y in range(8):
            out[t * 64 + y * 8: t * 64 + y * 8 + 8] = pixels[(oy + y) * 128 + ox: (oy + y) * 128 + ox + 8]
    return out


# ----------------------------------------------------------------------------
# Palettes
# ----------------------------------------------------------------------------

def snes_to_rgb(c):
    r, g, b = c & 31, (c >> 5) & 31, (c >> 10) & 31
    return (r << 3 | r >> 2, g << 3 | g >> 2, b << 3 | b >> 2)


TRANSPARENT = (0, 128, 128)  # teal, like the official extractor


def gray(n):
    return [(int(i * 255 / (n - 1)),) * 3 for i in range(n)]


HIGH_SPRITE_SHEETS = (0x52, 0x53, 0x5A, 0x5B, 0x5C, 0x5E, 0x5F)


class Palettes:
    """Builds preview palettes from the palette tables inside zelda3_assets.dat."""

    def __init__(self, af, sheet_meta, zspr=None):
        w = lambda name: list(array.array("H", af.get(name)))
        self.main_spr = w("kPalette_MainSpr")
        self.aux1 = w("kPalette_SpriteAux1")
        self.aux3 = w("kPalette_SpriteAux3")
        self.misc = w("kPalette_MiscSprite_Indoors")
        self.armor = w("kPalette_ArmorAndGloves")
        self.dung = w("kPalette_DungBgMain")
        self.ow_main = w("kPalette_OverworldBgMain")
        self.ow_aux12 = w("kPalette_OverworldBgAux12")
        self.ow_aux3 = w("kPalette_OverworldBgAux3")
        self.hud = w("kHudPalData")
        self.map = w("kOverworldMapPaletteData")
        self.sheet_meta = sheet_meta
        self.zspr = zspr
        self._cache = {}

    @staticmethod
    def _p(name, group, colors):
        return {"name": name, "group": group, "colors": ["#%02x%02x%02x" % c for c in colors]}

    def sprite_subset(self, pal_idx, j):
        # mirror of sprite_sheets.get_palette_subset, using the .dat tables
        j = j or 0
        if pal_idx == 0:
            return self.aux3[j * 7: j * 7 + 7]
        if pal_idx == 1:
            if j < 11:
                return self.misc[j * 7: j * 7 + 7]
            return self.dung[(j - 11) * 90: (j - 11) * 90 + 7]
        if 2 <= pal_idx <= 9:
            o = j * 60 + ((pal_idx - 2) >> 1) * 15 + (pal_idx & 1) * 8
            return self.main_spr[o: o + 7]
        if pal_idx in (10, 12):
            return self.aux1[j * 7: j * 7 + 7]
        if pal_idx == 13:
            return self.misc[j * 7: j * 7 + 7]
        if pal_idx == 14:
            return self.armor[1:8]
        if pal_idx == 15:
            return self.armor[9:16]
        return self.main_spr[0:7]

    def _three_bpp(self, kind, sheet):
        P = self._p
        T = [TRANSPARENT]
        conv = lambda ws: T + [snes_to_rgb(c) for c in ws]
        sprites, bgs = [], []
        meta = self.sheet_meta.get(sheet) if kind == "spr" else None
        if meta:
            pi, ps = meta["pal"]
            sprites.append(P("Sheet default (as used in game)", "Suggested", conv(self.sprite_subset(pi, ps))))
        for j, w in enumerate(("LW", "DW")):
            for row in range(4):
                for half, hn in ((0, "low"), (8, "high")):
                    o = j * 60 + row * 15 + half
                    sprites.append(P("Main sprite %s row %d (%s)" % (w, row, hn), "Sprite palettes",
                                     conv(self.main_spr[o: o + 7])))
        for j in range(len(self.aux1) // 7):
            sprites.append(P("Sprite aux1 #%d" % j, "Sprite palettes", conv(self.aux1[j * 7: j * 7 + 7])))
        for j in range(len(self.aux3) // 7):
            sprites.append(P("Sprite aux3 #%d" % j, "Sprite palettes", conv(self.aux3[j * 7: j * 7 + 7])))
        for j in range(len(self.misc) // 7):
            sprites.append(P("Misc sprite #%d" % j, "Sprite palettes", conv(self.misc[j * 7: j * 7 + 7])))
        sprites.append(P("Sword/armor (low)", "Sprite palettes", conv(self.armor[1:8])))
        sprites.append(P("Sword/armor (high)", "Sprite palettes", conv(self.armor[9:16])))
        for s in range(len(self.ow_main) // 35):
            for r in range(5):
                o = s * 35 + r * 7
                bgs.append(P("Overworld main %d row %d" % (s, r), "Overworld BG palettes", conv(self.ow_main[o: o + 7])))
        for s in range(len(self.ow_aux12) // 21):
            for r in range(3):
                o = s * 21 + r * 7
                bgs.append(P("Overworld aux %d row %d" % (s, r), "Overworld BG palettes", conv(self.ow_aux12[o: o + 7])))
        for s in range(len(self.ow_aux3) // 7):
            bgs.append(P("Overworld aux3 #%d" % s, "Overworld BG palettes", conv(self.ow_aux3[s * 7: s * 7 + 7])))
        dg = []
        for s in range(len(self.dung) // 90):
            for r in range(6):
                for half, hn in ((0, "low"), (8, "high")):
                    o = s * 90 + r * 15 + half
                    dg.append(P("Dungeon %d row %d (%s)" % (s, r, hn), "Dungeon BG palettes", conv(self.dung[o: o + 7])))
        g = [P("Grayscale", "Neutral", gray(8))]
        if kind == "spr":
            return sprites + bgs + dg + g
        # BG sheets: lead with the overworld palettes
        return bgs + dg + sprites + g

    def _two_bpp(self, default_row):
        out = []
        rows = list(range(len(self.hud) // 4))
        rows.remove(default_row)
        for r in [default_row] + rows:
            cols = [TRANSPARENT] + [snes_to_rgb(c) for c in self.hud[r * 4 + 1: r * 4 + 4]]
            out.append(self._p("HUD palette row %d" % r, "Suggested" if r == default_row else "HUD palettes", cols))
        out.append(self._p("Grayscale", "Neutral", gray(4)))
        return out

    def _link(self, use_zspr):
        out = []
        if use_zspr and self.zspr is not None:
            pal = self.zspr.palette_words()
            for k, nm in enumerate(("Green mail", "Blue mail", "Red mail", "Bunny")):
                if len(pal) >= k * 15 + 15:
                    out.append(self._p("%s (from .zspr)" % nm, "Suggested" if k == 0 else "Link palettes",
                                       [TRANSPARENT] + [snes_to_rgb(c) for c in pal[k * 15: k * 15 + 15]]))
        for k, nm in enumerate(("Green mail", "Blue mail", "Red mail", "Bunny", "Extra")):
            if len(self.armor) >= k * 15 + 15:
                out.append(self._p("%s (game default)" % nm, "Suggested" if not out else "Link palettes",
                                   [TRANSPARENT] + [snes_to_rgb(c) for c in self.armor[k * 15: k * 15 + 15]]))
        out.append(self._p("Grayscale", "Neutral", gray(16)))
        return out

    def _worldmap(self):
        out = []
        for nm, off in (("Light World map", 0), ("Dark World map", 128)):
            cols = [snes_to_rgb(c) for c in self.map[off: off + 128]]
            cols += [(255, 0, 255)] * (256 - len(cols))
            out.append(self._p(nm, "Suggested", cols))
        out.append(self._p("Grayscale", "Neutral", gray(256)))
        return out

    def for_asset(self, a):
        key = a.id
        if key in self._cache:
            return self._cache[key]
        if a.kind in ("spr", "bg") and a.bpp == 3:
            r = self._three_bpp(a.kind, a.index)
        elif a.bpp == 2:
            r = self._two_bpp(6 if a.kind == "font" else 2)
        elif a.kind == "link":
            r = self._link(False)
        elif a.kind == "zspr":
            r = self._link(True)
        elif a.kind == "worldmap":
            r = self._worldmap()
        else:
            r = [self._p("Grayscale", "Neutral", gray(1 << a.bpp))]
        self._cache[key] = r
        return r


def hex_to_rgb(h):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16))


# ----------------------------------------------------------------------------
# ZSPR (Link sprite) files
# ----------------------------------------------------------------------------

class Zspr:
    def __init__(self, path):
        self.path = path
        self.data = bytearray(open(path, "rb").read())
        d = self.data
        if len(d) < 27 or d[:4] != b"ZSPR":
            raise ValueError("not a ZSPR file")
        self.pix_off, self.pix_len = struct.unpack_from("<IH", d, 9)
        self.pal_off, self.pal_len = struct.unpack_from("<IH", d, 15)
        if self.pix_len != 0x7000 or self.pix_off + self.pix_len > len(d):
            raise ValueError("unexpected ZSPR pixel block")
        self.name = self._display_name()

    def _display_name(self):
        try:
            p = 29
            end = p
            while end + 1 < len(self.data) and (self.data[end] or self.data[end + 1]):
                end += 2
            s = self.data[p:end].decode("utf-16-le").strip()
            return s or os.path.basename(self.path)
        except Exception:
            return os.path.basename(self.path)

    def pixels(self):
        return bytes(self.data[self.pix_off: self.pix_off + 0x7000])

    def set_pixels(self, b):
        assert len(b) == 0x7000
        self.data[self.pix_off: self.pix_off + 0x7000] = b

    def palette_words(self):
        n = min(self.pal_len, 120) // 2
        return list(struct.unpack_from("<%dH" % n, self.data, self.pal_off))

    def save(self, path=None):
        path = path or self.path
        bak = path + ".orig"
        if not os.path.exists(bak) and os.path.exists(path):
            shutil.copy2(path, bak)
        open(path, "wb").write(self.data)


# ----------------------------------------------------------------------------
# Texture catalog
# ----------------------------------------------------------------------------

class Texture:
    def __init__(self, id, kind, index, label, group, bpp, w, h, note=""):
        self.id, self.kind, self.index = id, kind, index
        self.label, self.group = label, group
        self.bpp, self.w, self.h, self.note = bpp, w, h, note

    def to_json(self):
        return {"id": self.id, "kind": self.kind, "label": self.label, "group": self.group,
                "bpp": self.bpp, "w": self.w, "h": self.h, "note": self.note}


def load_sheet_meta(game_dir):
    """Sprite names / palette hints per sprite sheet, read from the game's own
    assets/sprite_sheet_info.py + tables.py when available."""
    adir = os.path.join(game_dir, "assets")
    if not os.path.exists(os.path.join(adir, "sprite_sheet_info.py")):
        return {}
    import importlib.util
    try:
        def load(name):
            spec = importlib.util.spec_from_file_location("_z3_" + name, os.path.join(adir, name + ".py"))
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            return m
        tables = load("tables")
        info = load("sprite_sheet_info")
    except Exception as e:  # pragma: no cover
        print("note: could not read sprite sheet names (%s)" % e)
        return {}

    def subidx(palset_idx, d, which):
        spmain = 1 if d == 1 else 0
        if d == 2:
            main, sp0l, sp5l, sp6l = tables.kDungPalinfos[palset_idx]
            sp0r, sp6r = (main // 2) + 11, 10
        else:
            sp5l, sp6l = tables.kOwSprPalInfo[palset_idx * 2: palset_idx * 2 + 2]
            sp0l = 3 if d == 1 else 1
            sp0r = 9 if d == 1 else 7
            sp6r = 8 if d == 1 else 6
        return (sp0l, sp0r, spmain, None, spmain, None, spmain, None, None, None,
                sp5l, None, sp6l, sp6r, None, None)[which]

    names, pals = {}, {}
    for e in info.entries:
        try:
            si = int(e.name[:2], 16) if e.name[0] != "X" else 10000
            t = e.tileset
            if e.dungeon_or_ow != 3:
                t = tables.kSpriteTilesets[t + (64 if e.dungeon_or_ow == 2 else 0)][e.ss_idx]
            pb = e.pal_base
            if pb is None:
                pb = (tables.kSpriteInit_Flags3[si] >> 1) & 7 if si < len(tables.kSpriteInit_Flags3) else 4
            pi = pb * 2 + (t in HIGH_SPRITE_SHEETS)
            ps = subidx(e.palset_idx, e.dungeon_or_ow, pi)
        except Exception:
            continue
        nm = re.sub(r"^[0-9A-Fa-fX]{2}: ", "", e.name)
        names.setdefault(t, [])
        if nm not in names[t] and not nm.startswith("Unknown Sheet"):
            names[t].append(nm)
        pals.setdefault(t, {})
        pals[t][(pi, ps)] = pals[t].get((pi, ps), 0) + 1
    meta = {}
    for t in names:
        best = max(pals[t].items(), key=lambda kv: kv[1])[0]
        meta[t] = {"names": names[t], "pal": list(best)}
    return meta


def read_ini_link_graphics(game_dir):
    ini = os.path.join(game_dir, "zelda3.ini")
    if not os.path.exists(ini):
        return None
    for line in open(ini, encoding="utf-8", errors="replace"):
        m = re.match(r"\s*LinkGraphics\s*=\s*(.+?)\s*$", line)
        if m and not line.lstrip().startswith("#"):
            p = m.group(1).strip().strip('"')
            if not p:
                return None
            if not os.path.isabs(p) and not re.match(r"^[A-Za-z]:[\\/]", p):
                p = os.path.join(game_dir, p)
            return p
    return None


class Project:
    def __init__(self, game_dir):
        self.game_dir = os.path.abspath(game_dir)
        self.dat_path = os.path.join(self.game_dir, "zelda3_assets.dat")
        if not os.path.exists(self.dat_path):
            raise SystemExit("zelda3_assets.dat not found in %s (use --game DIR)" % self.game_dir)
        self.lock = threading.RLock()
        self.sheet_meta = load_sheet_meta(self.game_dir)
        self.zspr = None
        self.zspr_error = None
        zp = read_ini_link_graphics(self.game_dir)
        if zp:
            try:
                self.zspr = Zspr(zp)
            except Exception as e:
                self.zspr_error = "%s: %s" % (zp, e)
        self.reload()

    # -- loading -------------------------------------------------------------
    def reload(self):
        with self.lock:
            self.af = AssetFile(self.dat_path)
            self.spr = unpack_array(self.af.get("kSprGfx"))
            self.bg = unpack_array(self.af.get("kBgGfx"))
            self.font_outer = unpack_array(self.af.get("kDialogueFont"))
            self.font_inner = [unpack_array(x) for x in self.font_outer]
            self.link = self.af.get("kLinkGraphics")
            self.worldmap = self.af.get("kOverworldMapGfx")
            if self.zspr:
                self.zspr = Zspr(self.zspr.path)
            self.palettes = Palettes(self.af, self.sheet_meta, self.zspr)
            self.pixels = {}       # current (possibly edited) pixel buffers
            self.original = {}     # pixels as loaded from disk
            self.dirty = set()
            self.textures = self._build_catalog()
            self.by_id = {t.id: t for t in self.textures}

    def _build_catalog(self):
        T = []
        for i, b in enumerate(self.spr):
            if i < 103:
                meta = self.sheet_meta.get(i)
                label = "Sprite sheet %d (0x%02X)" % (i, i)
                note = ", ".join(meta["names"][:12]) if meta and meta["names"] else ""
                if i < 12 and not note:
                    note = "Uncompressed sheet (items / common sprites)"
                if i in HIGH_SPRITE_SHEETS:
                    note = (note + " | " if note else "") + "uses upper palette half (colors 9-15)"
                T.append(Texture("spr_%03d" % i, "spr", i, label, "Sprite sheets (3bpp)", 3, 128, 32, note))
            else:
                T.append(Texture("spr_%03d" % i, "spr", i, "Sprite sheet %d (0x%02X)" % (i, i),
                                 "HUD / menu sheets (2bpp)", 2, 128, 64,
                                 "HUD, icons and menu graphics" if i >= 105 else ""))
        for i, b in enumerate(self.bg):
            if i < 113:
                empty = len(b) <= 8
                T.append(Texture("bg_%03d" % i, "bg", i, "BG tileset %d (0x%02X)%s" % (i, i, " (blank)" if empty else ""),
                                 "Background tilesets (3bpp)", 3, 128, 32,
                                 "Unused / blank slot" if empty else ""))
            else:
                T.append(Texture("bg_%03d" % i, "bg", i, "BG tileset %d (0x%02X)" % (i, i),
                                 "HUD / menu sheets (2bpp)", 2, 128, 64, ""))
        T.append(Texture("link", "link", 0, "Link (built-in, kLinkGraphics)", "Link", 4, 128, 448,
                         "Overridden in-game by LinkGraphics in zelda3.ini when set" if self.zspr else ""))
        if self.zspr:
            T.append(Texture("zspr_link", "zspr", 0, "Link (.zspr): %s" % self.zspr.name, "Link", 4, 128, 448,
                             "Active sprite from zelda3.ini: %s" % self.zspr.path))
        for li in range(len(self.font_inner)):
            T.append(Texture("font" if li == 0 else "font_%d" % li, "font", li, "Dialogue font" + ("" if li == 0 else " #%d" % li),
                             "Text & map", 2, 128, 128, "256 glyphs, 8x8. Glyph widths are kept as-is."))
        T.append(Texture("worldmap", "worldmap", 0, "World map (Mode 7)", "Text & map", 8, 128, 128,
                         "256 8x8 tiles used by the overworld map screen"))
        order = ["Sprite sheets (3bpp)", "Background tilesets (3bpp)", "HUD / menu sheets (2bpp)", "Link", "Text & map"]
        T.sort(key=lambda t: order.index(t.group) if t.group in order else 99)  # stable
        return T

    # -- pixels ----------------------------------------------------------------
    def _decode(self, t):
        if t.kind == "spr":
            b = self.spr[t.index]
            raw = b if (t.index < 12 or (t.index < 103 and len(b) == 0x600)) else decompress(b)
            return decode_tiles(raw, t.bpp, t.w, t.h)
        if t.kind == "bg":
            return decode_tiles(decompress(self.bg[t.index]), t.bpp, t.w, t.h)
        if t.kind == "link":
            return decode_tiles(self.link, 4, 128, 448)
        if t.kind == "zspr":
            return decode_tiles(self.zspr.pixels(), 4, 128, 448)
        if t.kind == "font":
            return decode_tiles(self.font_inner[t.index][0], 2, 128, 128)
        if t.kind == "worldmap":
            return decode_mode7(self.worldmap)
        raise KeyError(t.id)

    def get_pixels(self, tid):
        with self.lock:
            if tid not in self.pixels:
                t = self.by_id[tid]
                px = bytes(self._decode(t))
                self.pixels[tid] = px
                self.original[tid] = px
            return self.pixels[tid]

    def set_pixels(self, tid, px):
        with self.lock:
            self.get_pixels(tid)
            px = bytes(px)
            self.pixels[tid] = px
            if px == self.original[tid]:
                self.dirty.discard(tid)
            else:
                self.dirty.add(tid)

    def revert(self, tid):
        with self.lock:
            if tid in self.original:
                self.pixels[tid] = self.original[tid]
            self.dirty.discard(tid)

    # -- PNG I/O -----------------------------------------------------------------
    def palette_by_name(self, t, name):
        pals = self.palettes.for_asset(t)
        for p in pals:
            if p["name"] == name:
                return p
        return pals[0]

    def export_png(self, tid, palette_name=None):
        t = self.by_id[tid]
        pal = self.palette_by_name(t, palette_name)
        px = self.get_pixels(tid)
        img = Image.frombytes("P", (t.w, t.h), px)
        flat = []
        for c in pal["colors"]:
            flat.extend(hex_to_rgb(c))
        flat += [0] * (768 - len(flat))
        img.putpalette(flat)
        info = PngImagePlugin.PngInfo()
        info.add_text("zelda3-texture", t.id)
        info.add_text("zelda3-palette", pal["name"])
        info.add_text("zelda3-bpp", str(t.bpp))
        bio = io.BytesIO()
        kw = {"pnginfo": info}
        if t.kind != "worldmap":
            kw["transparency"] = 0
        img.save(bio, "PNG", **kw)
        return bio.getvalue()

    def png_to_pixels(self, tid, png_bytes, palette_name=None):
        """Returns (pixels, report dict). Raises ValueError on hard errors."""
        t = self.by_id[tid]
        img = Image.open(io.BytesIO(png_bytes))
        report = {"warnings": []}
        tag = img.info.get("zelda3-texture")
        if tag and tag != tid:
            report["warnings"].append("This PNG was exported from '%s', importing into '%s' anyway." % (tag, tid))
        if img.size != (t.w, t.h):
            raise ValueError("Image is %dx%d but %s must be exactly %dx%d." % (img.size[0], img.size[1], tid, t.w, t.h))
        ncol = 1 << t.bpp
        if t.kind == "worldmap":
            ncol = 256
        pal = self.palette_by_name(t, palette_name or img.info.get("zelda3-palette"))
        pal_rgb = [hex_to_rgb(c) for c in pal["colors"]][:ncol]
        report["palette"] = pal["name"]

        if img.mode == "P":
            idx = img.tobytes()
            mx = max(idx) if idx else 0
            if mx < ncol:
                report["mode"] = "indexed"
                report["inexact"] = 0
                return bytes(idx), report
            report["warnings"].append("Indexed PNG uses color index %d but this texture only has %d colors; "
                                      "matching by color instead." % (mx, ncol))
        # match by colour
        rgba = img.convert("RGBA")
        data = rgba.tobytes()
        out = bytearray(t.w * t.h)
        cache = {}
        inexact = 0
        # index 0 is transparent for every tiled sheet (not for the mode-7 map)
        cand = list(range(ncol)) if t.kind == "worldmap" else list(range(1, ncol))
        for i in range(t.w * t.h):
            r, g, b, a = data[i * 4: i * 4 + 4]
            if a < 128 and t.kind != "worldmap":
                out[i] = 0
                continue
            key = (r, g, b)
            v = cache.get(key)
            if v is None:
                best, bd = 0, 1 << 30
                for j in ([0] + cand if t.kind != "worldmap" else cand):
                    pr, pg, pb = pal_rgb[j]
                    d = (pr - r) ** 2 + (pg - g) ** 2 + (pb - b) ** 2
                    if d < bd:
                        best, bd = j, d
                v = (best, bd)
                cache[key] = v
            out[i] = v[0]
            if v[1] > 3 * 4 * 4:
                inexact += 1
        report["mode"] = "rgb"
        report["inexact"] = inexact
        used = set(out)
        seen = {}
        for j in sorted(used | set(range(len(pal_rgb)))):
            if j < len(pal_rgb):
                seen.setdefault(pal_rgb[j], []).append(j)
        dups = [v for v in seen.values() if len(v) > 1 and (t.kind == "worldmap" or 0 not in v)]
        if dups:
            report["warnings"].append(
                "Palette '%s' has identical colors at indices %s, so an RGB image can't tell them apart "
                "(the lowest index wins). Save as an indexed PNG to keep them distinct."
                % (pal["name"], "; ".join("/".join(map(str, d)) for d in dups[:4])))
        if inexact:
            report["warnings"].append("%d pixels did not exactly match a color in '%s' and were snapped to the nearest one."
                                      % (inexact, pal["name"]))
        return bytes(out), report

    def import_png(self, tid, png_bytes, palette_name=None):
        px, report = self.png_to_pixels(tid, png_bytes, palette_name)
        before = self.get_pixels(tid)
        t = self.by_id[tid]
        changed = 0
        tw = t.w // 8
        for ty in range(t.h // 8):
            for tx in range(tw):
                for y in range(8):
                    o = (ty * 8 + y) * t.w + tx * 8
                    if before[o: o + 8] != px[o: o + 8]:
                        changed += 1
                        break
        self.set_pixels(tid, px)
        report["changed_tiles"] = changed
        report["dirty"] = tid in self.dirty
        return report

    # -- saving ------------------------------------------------------------------
    def save(self):
        with self.lock:
            if not self.dirty:
                return {"saved": [], "message": "Nothing to save."}
            saved = []
            dat_changed = False
            zspr_changed = False
            for tid in sorted(self.dirty):
                t = self.by_id[tid]
                px = self.pixels[tid]
                if t.kind == "spr":
                    raw = bytes(encode_tiles(px, t.bpp, t.w, t.h))
                    # Sheets 0-102 may be stored uncompressed (exactly 0x600 bytes) - the game
                    # checks the size (Decomp_spr). Sheets 103+ must be compressed.
                    self.spr[t.index] = raw if t.index < 103 else compress(raw)
                    dat_changed = True
                elif t.kind == "bg":
                    self.bg[t.index] = compress(bytes(encode_tiles(px, t.bpp, t.w, t.h)))
                    dat_changed = True
                elif t.kind == "link":
                    self.link = bytes(encode_tiles(px, 4, 128, 448))
                    dat_changed = True
                elif t.kind == "zspr":
                    self.zspr.set_pixels(bytes(encode_tiles(px, 4, 128, 448)))
                    zspr_changed = True
                elif t.kind == "font":
                    self.font_inner[t.index][0] = bytes(encode_tiles(px, 2, 128, 128))
                    dat_changed = True
                elif t.kind == "worldmap":
                    self.worldmap = bytes(encode_mode7(px))
                    dat_changed = True
                saved.append(tid)
            backups = []
            if dat_changed:
                self.af.set("kSprGfx", pack_array(self.spr))
                self.af.set("kBgGfx", pack_array(self.bg))
                self.af.set("kLinkGraphics", self.link)
                self.af.set("kOverworldMapGfx", self.worldmap)
                self.af.set("kDialogueFont", pack_array([pack_array(x) for x in self.font_inner]))
                data = self.af.serialize()
                AssetFile_check(data)
                orig = self.dat_path + ".orig"
                if not os.path.exists(orig):
                    shutil.copy2(self.dat_path, orig)
                    backups.append(os.path.basename(orig))
                shutil.copy2(self.dat_path, self.dat_path + ".bak")
                backups.append(os.path.basename(self.dat_path) + ".bak")
                tmp = self.dat_path + ".tmp"
                open(tmp, "wb").write(data)
                os.replace(tmp, self.dat_path)
            if zspr_changed:
                self.zspr.save()
                backups.append(os.path.basename(self.zspr.path) + ".orig (first save only)")
            for tid in saved:
                self.original[tid] = self.pixels[tid]
            self.dirty.clear()
            return {"saved": saved, "backups": backups,
                    "message": "Saved %d texture(s). Restart the game to see the changes." % len(saved)}


def AssetFile_check(data):
    """Sanity-check a serialized asset file the same way the game loader does."""
    n, klen = struct.unpack_from("<II", data, 80)
    off = 88 + 4 * n + klen
    for i in range(n):
        size = struct.unpack_from("<I", data, 88 + i * 4)[0]
        off = (off + 3) & ~3
        if off + size > len(data):
            raise RuntimeError("serialized asset file is inconsistent")
        off += size


# ----------------------------------------------------------------------------
# Batch export / import
# ----------------------------------------------------------------------------

def export_all(proj, outdir):
    os.makedirs(outdir, exist_ok=True)
    for t in proj.textures:
        open(os.path.join(outdir, t.id + ".png"), "wb").write(proj.export_png(t.id))
    readme = os.path.join(outdir, "_README.txt")
    with open(readme, "w") as f:
        f.write(EXPORT_README)
    return len(proj.textures)


def import_all(proj, indir, log=print):
    n = 0
    for t in proj.textures:
        p = os.path.join(indir, t.id + ".png")
        if not os.path.exists(p):
            continue
        try:
            rep = proj.import_png(t.id, open(p, "rb").read())
        except ValueError as e:
            log("  %-10s ERROR: %s" % (t.id, e))
            continue
        if rep["dirty"]:
            n += 1
            log("  %-10s %d tile(s) changed" % (t.id, rep["changed_tiles"]))
            for w in rep["warnings"]:
                log("             ! " + w)
    return n


EXPORT_README = """Zelda3 Texture Tool export
==========================
Each PNG is an *indexed* (palette) image. The pixel's palette INDEX is what the
game stores - the colors are only a preview palette. Rules for editing:

 * Keep the image size exactly the same.
 * Index 0 is transparent (shown teal).
 * Best: keep the image in indexed mode (Aseprite, GraphicsGale, Photoshop
   Image > Mode > Indexed). Only use indices 0-7 for 3bpp sheets, 0-3 for 2bpp,
   0-15 for Link.
 * If your editor saves RGB, the tool matches each pixel to the closest color
   of the preview palette it was exported with, and fully transparent pixels
   become index 0.

File names:  spr_NNN = sprite sheet, bg_NNN = background tileset,
             link = built-in Link, zspr_link = the .zspr set in zelda3.ini,
             font = dialogue font, worldmap = Mode 7 overworld map tiles.

Import with:  zelda3_texture_tool.py import-all <this folder>
or one at a time from the browser UI.
"""

# ----------------------------------------------------------------------------
# Web UI
# ----------------------------------------------------------------------------

def default_export_dir(proj):
    return os.path.join(proj.game_dir, "texture_tool", "export")


def app_data_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "Zelda3TextureTool")
    os.makedirs(d, exist_ok=True)
    return d


def open_app_window(url):
    """Open the UI in a chromeless Edge/Chrome window if possible, else the default browser."""
    if os.name == "nt":
        import subprocess
        env = os.environ
        cands = []
        for base in (env.get("PROGRAMFILES(X86)"), env.get("PROGRAMFILES"), env.get("LOCALAPPDATA")):
            if base:
                cands.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
                cands.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
        for c in cands:
            if os.path.exists(c):
                try:
                    subprocess.Popen([c, "--app=" + url, "--window-size=1440,920"])
                    return
                except OSError:
                    pass
    import webbrowser
    webbrowser.open(url)


def run_server(proj, port=0, open_browser=True, exit_when_closed=False):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    html = HTML_PAGE.encode("utf-8")
    life = {"start": time.time(), "last": 0.0, "bye": None}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body, ctype="application/json", extra=None):
            if isinstance(body, (dict, list)):
                body = json.dumps(body).encode()
            elif isinstance(body, str):
                body = body.encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _q(self):
            u = urllib.parse.urlparse(self.path)
            return u.path, {k: v[-1] for k, v in urllib.parse.parse_qs(u.query).items()}

        def do_GET(self):
            path, q = self._q()
            life["last"] = time.time()
            try:
                if path == "/":
                    return self._send(200, html, "text/html; charset=utf-8")
                if path == "/api/ping":
                    return self._send(200, {"ok": True})
                if path == "/api/list":
                    return self._send(200, {
                        "game_dir": proj.game_dir,
                        "textures": [t.to_json() for t in proj.textures],
                        "dirty": sorted(proj.dirty),
                        "zspr_error": proj.zspr_error,
                        "version": TOOL_VERSION,
                    })
                if path == "/api/texture":
                    t = proj.by_id[q["id"]]
                    px = proj.get_pixels(t.id)
                    return self._send(200, {
                        "info": t.to_json(),
                        "pixels": base64.b64encode(px).decode(),
                        "palettes": proj.palettes.for_asset(t),
                        "dirty": t.id in proj.dirty,
                    })
                if path == "/api/export":
                    t = proj.by_id[q["id"]]
                    png = proj.export_png(t.id, q.get("palette"))
                    return self._send(200, png, "image/png",
                                      {"Content-Disposition": 'attachment; filename="%s.png"' % t.id})
                return self._send(404, {"error": "not found"})
            except KeyError as e:
                return self._send(404, {"error": "unknown texture %s" % e})
            except Exception as e:
                return self._send(500, {"error": str(e)})

        def do_POST(self):
            path, q = self._q()
            life["last"] = time.time()
            n = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(n) if n else b""
            try:
                if path == "/api/bye":
                    life["bye"] = time.time()
                    return self._send(200, {"ok": True})
                if path == "/api/pixels":
                    t = proj.by_id[q["id"]]
                    if len(body) != t.w * t.h:
                        raise ValueError("expected %d bytes, got %d" % (t.w * t.h, len(body)))
                    ncol = 256 if t.kind == "worldmap" else 1 << t.bpp
                    if body and max(body) >= ncol:
                        raise ValueError("color slot %d is out of range (max %d)" % (max(body), ncol - 1))
                    proj.set_pixels(t.id, body)
                    return self._send(200, {"dirty": sorted(proj.dirty)})
                if path == "/api/import":
                    rep = proj.import_png(q["id"], body, q.get("palette"))
                    return self._send(200, rep)
                if path == "/api/revert":
                    proj.revert(q["id"])
                    return self._send(200, {"ok": True})
                if path == "/api/save":
                    return self._send(200, proj.save())
                if path == "/api/export-all":
                    d = default_export_dir(proj)
                    c = export_all(proj, d)
                    if os.name == "nt" and q.get("open"):
                        try:
                            os.startfile(d)
                        except OSError:
                            pass
                    return self._send(200, {"message": "Exported %d PNGs to %s" % (c, d), "dir": d})
                if path == "/api/import-all":
                    d = default_export_dir(proj)
                    if not os.path.isdir(d):
                        raise ValueError("%s doesn't exist yet - use Export all first." % d)
                    lines = []
                    c = import_all(proj, d, lines.append)
                    return self._send(200, {"message": "%d texture(s) changed from %s (not saved yet)" % (c, d),
                                            "log": lines, "dirty": sorted(proj.dirty)})
                return self._send(404, {"error": "not found"})
            except KeyError as e:
                return self._send(404, {"error": "unknown texture %s" % e})
            except ValueError as e:
                return self._send(400, {"error": str(e)})
            except Exception as e:
                return self._send(500, {"error": "%s: %s" % (type(e).__name__, e)})

    srv = None
    if port == 0:
        # Prefer a fixed port so the browser remembers UI settings between runs.
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", DEFAULT_PORT), H)
        except OSError:
            # Already running? Then just show that instance.
            try:
                r = json.loads(urllib.request.urlopen("http://127.0.0.1:%d/api/list" % DEFAULT_PORT, timeout=3).read())
                if os.path.normcase(os.path.abspath(r.get("game_dir", ""))) == os.path.normcase(proj.game_dir):
                    if open_browser:
                        open_app_window("http://127.0.0.1:%d/" % DEFAULT_PORT)
                    print("Already running - opened the existing window.")
                    return
            except Exception:
                pass
    if srv is None:
        srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    url = "http://127.0.0.1:%d/" % srv.server_address[1]
    print("Zelda3 Texture Tool running at %s" % url)
    print("Game folder: %s" % proj.game_dir)
    print("Close this window (or press Ctrl+C) to stop.")

    if exit_when_closed:
        # The page pings every few seconds; quit once the window has been closed.
        def watchdog():
            while True:
                time.sleep(1)
                now = time.time()
                if not life["last"]:
                    if now - life["start"] > 180:
                        os._exit(0)
                    continue
                if life["bye"] and life["last"] <= life["bye"] + 0.01 and now - life["bye"] > 8:
                    os._exit(0)
                if now - life["last"] > 200:
                    os._exit(0)
        threading.Thread(target=watchdog, daemon=True).start()

    if open_browser:
        threading.Timer(0.3, lambda: open_app_window(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


HTML_PAGE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zelda3 Texture Tool</title>
<style>
:root{--bg:#14161a;--panel:#1c1f25;--panel2:#23272f;--line:#30353f;--text:#e4e6ea;--dim:#8d94a1;
--acc:#d8b74a;--acc2:#5aa469;--warn:#e0884a;--err:#e05a5a;--mono:ui-monospace,Consolas,monospace}
*{box-sizing:border-box}html,body{height:100%;margin:0}
body{background:var(--bg);color:var(--text);font:14px/1.4 system-ui,Segoe UI,sans-serif;display:flex;flex-direction:column;overflow:hidden}
header{display:flex;align-items:center;gap:10px;padding:8px 14px;border-bottom:1px solid var(--line);background:var(--panel)}
header h1{font-size:15px;margin:0;letter-spacing:.04em;color:var(--acc);font-weight:700;white-space:nowrap}
header .path{color:var(--dim);font:12px var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
button,select,input[type=search],input[type=number]{background:var(--panel2);color:var(--text);border:1px solid var(--line);border-radius:6px;padding:5px 10px;font:inherit}
button{cursor:pointer;white-space:nowrap}button:hover{border-color:#4a5160}
button:disabled{opacity:.4;cursor:default}
button.primary{background:var(--acc);color:#1a1606;border-color:var(--acc);font-weight:600}
button.tool{padding:5px 9px}button.tool.on{background:#3a3420;border-color:var(--acc);color:#fff}
button kbd{font:11px var(--mono);color:var(--dim);margin-left:4px}
main{flex:1;display:flex;min-height:0}
aside{width:250px;border-right:1px solid var(--line);display:flex;flex-direction:column;background:var(--panel)}
aside .search{padding:10px}aside input{width:100%}
#list{overflow:auto;flex:1;padding:0 6px 12px}
.grp{color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:.08em;padding:12px 8px 4px;cursor:pointer;user-select:none}
.grp::before{content:"▾ "}.grp.closed::before{content:"▸ "}
.item{padding:5px 8px;border-radius:5px;cursor:pointer;display:flex;gap:6px;align-items:baseline}
.item:hover{background:var(--panel2)}.item.sel{background:#3a3420;color:#fff}
.item .t{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.item .sub{color:var(--dim);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.item .dot{width:7px;height:7px;border-radius:50%;background:var(--warn);flex:none;align-self:center;visibility:hidden}
.item.dirty .dot{visibility:visible}
section{flex:1;display:flex;flex-direction:column;min-width:0}
.bar{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:7px 14px;border-bottom:1px solid var(--line)}
.bar .sp{flex:1}.bar .sep{width:1px;height:22px;background:var(--line);margin:0 4px}
.bar label{color:var(--dim);font-size:12px;display:flex;align-items:center;gap:5px;white-space:nowrap}
.bar.edit{background:#191b20}
#palette{max-width:240px}
.info{padding:8px 14px 0;display:flex;gap:14px;align-items:flex-start}
.info .txt{flex:1;min-width:0}
.info h2{margin:0;font-size:16px}.info .note{color:var(--dim);font-size:12.5px;margin-top:2px}
.ps{position:relative;width:46px;height:40px;flex:none;cursor:pointer}
.ps div{position:absolute;width:28px;height:28px;border:2px solid #000;border-radius:4px;font:10px var(--mono);color:#fff;text-shadow:0 0 2px #000,0 0 2px #000;display:flex;align-items:flex-end;justify-content:flex-end;padding:1px 2px}
.ps .p{left:0;top:0;z-index:2;outline:2px solid var(--acc)}.ps .s{left:16px;top:12px;outline:1px solid #fff}
.swatches{display:flex;flex-wrap:wrap;gap:3px;padding:8px 14px}
.sw{width:24px;height:24px;border-radius:3px;border:1px solid #0008;font:9px var(--mono);color:#fff;text-shadow:0 0 2px #000,0 0 2px #000;display:flex;align-items:flex-end;justify-content:flex-end;padding:1px 2px;cursor:pointer;position:relative}
.sw.small{width:12px;height:12px;padding:0;font-size:0;border-radius:2px}
.sw.p{outline:2px solid var(--acc);outline-offset:1px;z-index:2}.sw.s{box-shadow:0 0 0 2px #fff inset}
.sw.p::before{content:"L";position:absolute;left:2px;top:0;font-size:9px}.sw.s::after{content:"R";position:absolute;left:2px;top:0;font-size:9px}
.sw.small::before,.sw.small::after{content:none}
#stage{flex:1;overflow:auto;padding:16px;background:repeating-conic-gradient(#1a1d22 0 25%,#16181c 0 50%) 0 0/24px 24px;position:relative}
#cv{image-rendering:pixelated;box-shadow:0 0 0 1px var(--line);display:block;touch-action:none}
#cv.t-pencil,#cv.t-fill{cursor:crosshair}#cv.t-picker{cursor:copy}#cv.t-select{cursor:cell}
.status{display:flex;gap:16px;padding:5px 14px;border-top:1px solid var(--line);color:var(--dim);font:12px var(--mono);background:var(--panel);white-space:nowrap;overflow:hidden}
#toast{position:fixed;right:16px;bottom:40px;max-width:480px;background:var(--panel2);border:1px solid var(--line);border-left:4px solid var(--acc2);border-radius:6px;padding:10px 14px;display:none;white-space:pre-wrap;box-shadow:0 6px 24px #0008;z-index:10}
#toast.err{border-left-color:var(--err)}#toast.warn{border-left-color:var(--warn)}
.drop{outline:2px dashed var(--acc);outline-offset:-8px}
dialog{background:var(--panel);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:18px 20px;min-width:360px;box-shadow:0 12px 40px #000a}
dialog::backdrop{background:#0008}
dialog h3{margin:0 0 12px;font-size:16px}
dialog .row{display:flex;gap:10px;align-items:center;margin:10px 0}
dialog .row label{color:var(--dim);min-width:70px}
dialog .btns{display:flex;justify-content:flex-end;gap:8px;margin-top:16px}
dialog .help{color:var(--dim);font-size:12.5px}
.slotpick{display:flex;flex-wrap:wrap;gap:3px;max-width:420px}
.slotpick .sw.on{outline:2px solid var(--acc);outline-offset:1px}
#help td{padding:2px 12px 2px 0}#help td:first-child{font:12px var(--mono);color:var(--acc);white-space:nowrap}
</style></head><body>
<header><h1>ZELDA3 TEXTURE TOOL</h1><div class="path" id="gamedir"></div>
<button id="helpBtn">Shortcuts</button>
<button id="exportAll" title="Write every texture as PNG into texture_tool\export">Export all</button>
<button id="importAll" title="Load changed PNGs from texture_tool\export">Import all</button>
<button id="save" class="primary" disabled>Save to game</button></header>
<main>
<aside><div class="search"><input type="search" id="q" placeholder="Filter (e.g. moblin, 0x5e, font)"></div><div id="list"></div></aside>
<section>
 <div class="bar">
  <label>Palette <select id="palette"></select></label>
  <label>Zoom <select id="zoom"><option>1</option><option>2</option><option>3</option><option selected>4</option><option>6</option><option>8</option><option>12</option><option>16</option><option>24</option></select></label>
  <label><input type="checkbox" id="grid" checked> Tiles</label>
  <label><input type="checkbox" id="pgrid" checked> Pixels</label>
  <label title="Draws each pixel's color slot number (zoom 12+)"><input type="checkbox" id="nums"> Numbers</label>
  <label title="Show slot 0 as transparent"><input type="checkbox" id="trans" checked> Slot 0 clear</label>
  <span class="sp"></span>
  <button id="export">Export PNG</button>
  <button id="import">Import…</button>
  <button id="revert" title="Discard all unsaved changes to this texture">Revert</button>
  <input type="file" id="file" accept="image/png" hidden>
 </div>
 <div class="bar edit">
  <button class="tool" data-tool="pencil" title="Pencil (B): left = L slot, right = R slot">✎ Pencil<kbd>B</kbd></button>
  <button class="tool" data-tool="fill" title="Fill (G)">◩ Fill<kbd>G</kbd></button>
  <button class="tool" data-tool="picker" title="Pick slot from image (I) — or Alt+click with any tool">⌖ Pick<kbd>I</kbd></button>
  <button class="tool" data-tool="select" title="Select area (M)">⬚ Select<kbd>M</kbd></button>
  <label title="Fill stays inside the 8×8 tile you click"><input type="checkbox" id="filltile" checked> Fill in tile</label>
  <label title="Selections snap to whole 8×8 tiles"><input type="checkbox" id="snap"> Snap to tiles</label>
  <span class="sep"></span>
  <button id="undo" title="Undo (Ctrl+Z)">↶</button>
  <button id="redo" title="Redo (Ctrl+Y)">↷</button>
  <span class="sep"></span>
  <button id="copy" title="Copy selection (Ctrl+C)">Copy</button>
  <button id="paste" title="Paste at the selection's top-left, or under the mouse (Ctrl+V)">Paste</button>
  <button id="flipH" title="Flip selection horizontally (H)">↔</button>
  <button id="flipV" title="Flip selection vertically (V)">↕</button>
  <button id="clear" title="Set selection to slot 0 (Delete)">Clear</button>
  <button id="remap" title="Replace or swap color slots in the selection or whole sheet (R)">Remap…</button>
 </div>
 <div class="info">
  <div class="ps" id="ps" title="L / R drawing slots — X swaps them"><div class="s" id="psS"></div><div class="p" id="psP"></div></div>
  <div class="txt"><h2 id="title">Select a texture</h2><div class="note" id="note"></div></div>
 </div>
 <div class="swatches" id="sw"></div>
 <div id="stage"><canvas id="cv" class="t-pencil"></canvas></div>
 <div class="status"><span id="st1">—</span><span id="st2"></span><span id="st4"></span><span id="st3"></span></div>
</section></main>
<div id="toast"></div>

<dialog id="remapDlg"><form method="dialog">
 <h3>Remap color slots</h3>
 <div class="help">Changes which numbered slot pixels use. The game stores slot numbers, so this is how you recolor a sprite without touching palettes.</div>
 <div class="row"><label>From slot</label><div class="slotpick" id="rmFrom"></div></div>
 <div class="row"><label>To slot</label><div class="slotpick" id="rmTo"></div></div>
 <div class="row"><label>Mode</label>
  <label style="min-width:0"><input type="radio" name="rmMode" value="replace" checked> Replace From → To</label>
  <label style="min-width:0"><input type="radio" name="rmMode" value="swap"> Swap both</label></div>
 <div class="row"><label>Where</label>
  <label style="min-width:0"><input type="radio" name="rmScope" value="sel" id="rmScopeSel"> Selection</label>
  <label style="min-width:0"><input type="radio" name="rmScope" value="all" id="rmScopeAll" checked> Whole sheet</label></div>
 <div class="help" id="rmCount"></div>
 <div class="btns"><button value="cancel">Cancel</button><button value="ok" class="primary" id="rmOk">Apply</button></div>
</form></dialog>

<dialog id="helpDlg"><form method="dialog">
 <h3>Editing</h3>
 <table id="help">
 <tr><td>Left / Right click</td><td>Draw with the L / R slot (Pencil), fill (Fill), pick (Pick)</td></tr>
 <tr><td>Alt + click</td><td>Pick a slot from the image with any tool</td></tr>
 <tr><td>B G I M</td><td>Pencil, Fill, Pick, Select</td></tr>
 <tr><td>0–9</td><td>Set L slot (hold Shift for R slot)</td></tr>
 <tr><td>[ ]</td><td>Previous / next L slot</td></tr>
 <tr><td>X</td><td>Swap L and R slots</td></tr>
 <tr><td>Ctrl+Z / Ctrl+Y</td><td>Undo / Redo</td></tr>
 <tr><td>Ctrl+C / X / V</td><td>Copy / Cut / Paste (at selection, or under mouse)</td></tr>
 <tr><td>H / V</td><td>Flip selection</td></tr>
 <tr><td>Delete</td><td>Clear selection to slot 0</td></tr>
 <tr><td>R</td><td>Remap slots…</td></tr>
 <tr><td>Esc</td><td>Deselect</td></tr>
 <tr><td>Ctrl + wheel, + / −</td><td>Zoom</td></tr>
 <tr><td>Ctrl+S</td><td>Save to game</td></tr>
 </table>
 <div class="help" style="margin-top:10px">Edits are kept in the tool until you press <b>Save to game</b>. The palette menu only changes the preview — pixels store slot numbers.</div>
 <div class="btns"><button value="ok" class="primary">Close</button></div>
</form></dialog>

<script>
const $=s=>document.querySelector(s);
const store={get(k,d){try{const v=localStorage.getItem('z3tt:'+k);return v===null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem('z3tt:'+k,JSON.stringify(v))}catch(e){}}};
let TEX=[],DIRTY=new Set(),cur=null,data=null,closed=new Set(store.get('closed',[]));
let tool='pencil',prim=1,sec=0,sel=null,clip=null,hover=null,cols=[],off=null,offImg=null;
const HIST=new Map();  // id -> {undo:[],redo:[]}
let pushTimer=null,pushing=Promise.resolve();

function toast(msg,kind){const t=$('#toast');t.textContent=msg;t.className=kind||'';t.style.display='block';clearTimeout(t._h);t._h=setTimeout(()=>t.style.display='none',kind==='err'?9000:5000)}
async function api(path,opt){const r=await fetch(path,opt);const j=await r.json().catch(()=>({error:'bad response'}));if(!r.ok)throw new Error(j.error||r.statusText);return j}
function setDirty(list){DIRTY=new Set(list);$('#save').disabled=DIRTY.size===0;$('#save').textContent=DIRTY.size?`Save to game (${DIRTY.size})`:'Save to game';
 document.querySelectorAll('.item').forEach(e=>e.classList.toggle('dirty',DIRTY.has(e.dataset.id)));$('#st3').textContent=DIRTY.has(cur)?'● unsaved changes':''}
function ncol(){return data?(data.info.kind==='worldmap'?256:1<<data.info.bpp):8}
function hist(){if(!HIST.has(cur))HIST.set(cur,{undo:[],redo:[]});return HIST.get(cur)}

/* ---------- list ---------- */
function renderList(){const q=$('#q').value.trim().toLowerCase();const L=$('#list');L.innerHTML='';let g=null,box=null;
 for(const t of TEX){const hay=(t.id+' '+t.label+' '+t.note).toLowerCase();if(q&&!hay.includes(q))continue;
  if(t.group!==g){g=t.group;const h=document.createElement('div');h.className='grp'+(closed.has(g)&&!q?' closed':'');h.textContent=g;
   const gg=g;h.onclick=()=>{closed.has(gg)?closed.delete(gg):closed.add(gg);store.set('closed',[...closed]);renderList()};L.appendChild(h);
   box=document.createElement('div');if(closed.has(g)&&!q)box.style.display='none';L.appendChild(box)}
  const d=document.createElement('div');d.className='item'+(cur===t.id?' sel':'')+(DIRTY.has(t.id)?' dirty':'');d.dataset.id=t.id;
  d.innerHTML='<span class="dot"></span><div style="min-width:0"><div class="t"></div><div class="sub"></div></div>';
  d.querySelector('.t').textContent=t.label.replace(/ \(0x..\)/,'');d.querySelector('.sub').textContent=t.note||t.id;d.title=t.note||'';
  d.onclick=()=>select(t.id);box.appendChild(d)}}
async function load(){const j=await api('/api/list');TEX=j.textures;$('#gamedir').textContent=j.game_dir;renderList();setDirty(j.dirty);
 if(j.zspr_error)toast('Could not read the .zspr from zelda3.ini:\n'+j.zspr_error,'warn');
 const last=store.get('last',null);await select(TEX.find(t=>t.id===last)?last:TEX[0].id)}

/* ---------- texture load / sync ---------- */
async function flush(){if(pushTimer){clearTimeout(pushTimer);pushTimer=null;await pushNow()}await pushing}
function schedulePush(){clearTimeout(pushTimer);pushTimer=setTimeout(()=>{pushTimer=null;pushNow()},250)}
function pushNow(){if(!data)return Promise.resolve();const id=cur,body=data.px.slice();
 pushing=pushing.then(()=>api('/api/pixels?id='+encodeURIComponent(id),{method:'POST',body}).then(r=>setDirty(r.dirty)).catch(e=>toast('Could not apply edit: '+e.message,'err')));return pushing}
async function select(id){await flush();cur=id;store.set('last',id);sel=null;
 document.querySelectorAll('.item').forEach(e=>e.classList.toggle('sel',e.dataset.id===id));
 const j=await api('/api/texture?id='+encodeURIComponent(id));if(cur!==id)return;data=j;
 const raw=atob(j.pixels);data.px=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)data.px[i]=raw.charCodeAt(i);
 const s=$('#palette');s.innerHTML='';let grp=null,og=null;
 j.palettes.forEach((p,i)=>{if(p.group!==grp){grp=p.group;og=document.createElement('optgroup');og.label=grp;s.appendChild(og)}
  const o=document.createElement('option');o.value=i;o.textContent=p.name;og.appendChild(o)});
 const saved=store.get('pal:'+id,null);const k=j.palettes.findIndex(p=>p.name===saved);s.value=k>=0?k:0;
 const n=ncol();if(prim>=n)prim=Math.min(1,n-1);if(sec>=n)sec=0;
 $('#title').textContent=j.info.label;
 $('#note').textContent=[j.info.note||(j.info.kind==='bg'?'Overworld / dungeon tiles. In game each slot uses the low or high half of a 16-color BG palette.':''),`${j.info.w}×${j.info.h} px · ${j.info.bpp}bpp · ${n} slots · ${j.info.id}.png`].filter(Boolean).join('  —  ');
 setDirty([...DIRTY]);buildImage();updateUndo()}
function pal(){return data.palettes[+$('#palette').value]||data.palettes[0]}

/* ---------- rendering ---------- */
function buildImage(){if(!data)return;const P=pal(),{w,h}=data.info;
 cols=P.colors.map(c=>[parseInt(c.slice(1,3),16),parseInt(c.slice(3,5),16),parseInt(c.slice(5,7),16)]);
 off=document.createElement('canvas');off.width=w;off.height=h;offImg=new ImageData(w,h);
 for(let i=0;i<w*h;i++)paintPix(i);renderSwatches();draw()}
function paintPix(i){const v=data.px[i],c=cols[v]||[255,0,255],d=offImg.data,tr=$('#trans').checked&&data.info.kind!=='worldmap';
 d[i*4]=c[0];d[i*4+1]=c[1];d[i*4+2]=c[2];d[i*4+3]=(tr&&v===0)?0:255}
let rafPending=false;function draw(){if(rafPending)return;rafPending=true;requestAnimationFrame(()=>{rafPending=false;drawNow()})}
function drawNow(){if(!data)return;const z=+$('#zoom').value,{w,h}=data.info,cv=$('#cv');
 off.getContext('2d').putImageData(offImg,0,0);
 if(cv.width!==w*z||cv.height!==h*z){cv.width=w*z;cv.height=h*z}
 const g=cv.getContext('2d');g.imageSmoothingEnabled=false;g.clearRect(0,0,cv.width,cv.height);g.drawImage(off,0,0,w*z,h*z);
 const st=$('#stage'),vx0=Math.max(0,Math.floor((st.scrollLeft-16)/z)),vy0=Math.max(0,Math.floor((st.scrollTop-16)/z));
 const vx1=Math.min(w,Math.ceil((st.scrollLeft+st.clientWidth)/z)+1),vy1=Math.min(h,Math.ceil((st.scrollTop+st.clientHeight)/z)+1);
 if($('#pgrid').checked&&z>=8){g.strokeStyle='rgba(255,255,255,.06)';g.lineWidth=1;g.beginPath();
  for(let x=vx0;x<=vx1;x++){g.moveTo(x*z+.5,vy0*z);g.lineTo(x*z+.5,vy1*z)}for(let y=vy0;y<=vy1;y++){g.moveTo(vx0*z,y*z+.5);g.lineTo(vx1*z,y*z+.5)}g.stroke()}
 if($('#grid').checked&&z>=2){g.strokeStyle='rgba(255,255,255,.18)';g.lineWidth=1;g.beginPath();
  for(let x=8;x<w;x+=8){g.moveTo(x*z+.5,0);g.lineTo(x*z+.5,h*z)}for(let y=8;y<h;y+=8){g.moveTo(0,y*z+.5);g.lineTo(w*z,y*z+.5)}g.stroke()}
 if($('#nums').checked&&z>=12){g.font=`${Math.max(8,Math.floor(z*.45))}px ui-monospace,Consolas,monospace`;g.textAlign='center';g.textBaseline='middle';
  for(let y=vy0;y<vy1;y++)for(let x=vx0;x<vx1;x++){const v=data.px[y*w+x],c=cols[v]||[255,0,255];const lum=c[0]*.3+c[1]*.59+c[2]*.11;
   g.fillStyle=lum>140?'rgba(0,0,0,.75)':'rgba(255,255,255,.85)';g.fillText(String(v),x*z+z/2,y*z+z/2+.5)}}
 if(hover&&tool!=='select'&&z>=4){g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1;g.strokeRect(hover.x*z+.5,hover.y*z+.5,z-1,z-1)}
 if(sel){g.save();g.lineWidth=2;g.strokeStyle='#000';g.strokeRect(sel.x*z+1,sel.y*z+1,sel.w*z-2,sel.h*z-2);
  g.setLineDash([5,4]);g.strokeStyle=getComputedStyle(document.body).getPropertyValue('--acc');g.strokeRect(sel.x*z+1,sel.y*z+1,sel.w*z-2,sel.h*z-2);g.restore()}
 $('#st1').textContent=`${data.info.id}  ${w}×${h}`+(sel?`  · selection ${sel.w}×${sel.h} at ${sel.x},${sel.y}`:'')}
function renderSwatches(){const P=pal(),sw=$('#sw');sw.innerHTML='';const n=ncol(),small=n>16;
 for(let i=0;i<n;i++){const c=P.colors[i]||'#ff00ff';const d=document.createElement('div');d.className='sw'+(small?' small':'')+(i===prim?' p':'')+(i===sec?' s':'');
  d.style.background=c;d.title=`slot ${i}  ${c}  — left click: L slot, right click: R slot`;if(!small)d.textContent=i;
  d.onmousedown=e=>{e.preventDefault();if(e.button===2)sec=i;else prim=i;renderSwatches()};d.oncontextmenu=e=>e.preventDefault();sw.appendChild(d)}
 const pc=P.colors[prim]||'#f0f',sc=P.colors[sec]||'#f0f';$('#psP').style.background=pc;$('#psP').textContent=prim;$('#psS').style.background=sc;$('#psS').textContent=sec;
 $('#st4').textContent=`L slot ${prim} · R slot ${sec}`}

/* ---------- editing primitives ---------- */
function snapshot(){const H=hist();H.undo.push(data.px.slice());if(H.undo.length>200)H.undo.shift();H.redo.length=0;updateUndo()}
function updateUndo(){const H=cur?hist():{undo:[],redo:[]};$('#undo').disabled=!H.undo.length;$('#redo').disabled=!H.redo.length;
 const has=!!sel;['#copy','#flipH','#flipV','#clear'].forEach(s=>$(s).disabled=!has);$('#paste').disabled=!clip}
function commit(){schedulePush();updateUndo();draw()}
function restore(px){data.px.set(px);for(let i=0;i<px.length;i++)paintPix(i);commit()}
function undo(){const H=hist();if(!H.undo.length)return;H.redo.push(data.px.slice());restore(H.undo.pop())}
function redo(){const H=hist();if(!H.redo.length)return;H.undo.push(data.px.slice());restore(H.redo.pop())}
function setPx(x,y,v){const w=data.info.w;if(x<0||y<0||x>=w||y>=data.info.h)return false;const i=y*w+x;if(data.px[i]===v)return false;data.px[i]=v;paintPix(i);return true}
function line(x0,y0,x1,y1,v){let dx=Math.abs(x1-x0),dy=-Math.abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1,e=dx+dy;
 for(;;){setPx(x0,y0,v);if(x0===x1&&y0===y1)break;const e2=2*e;if(e2>=dy){e+=dy;x0+=sx}if(e2<=dx){e+=dx;y0+=sy}}}
function flood(x,y,v){const {w,h}=data.info,px=data.px,t=px[y*w+x];if(t===v)return;
 let bx0=0,by0=0,bx1=w-1,by1=h-1;if($('#filltile').checked){bx0=x&~7;by0=y&~7;bx1=bx0+7;by1=by0+7}
 if(sel&&x>=sel.x&&y>=sel.y&&x<sel.x+sel.w&&y<sel.y+sel.h){bx0=Math.max(bx0,sel.x);by0=Math.max(by0,sel.y);bx1=Math.min(bx1,sel.x+sel.w-1);by1=Math.min(by1,sel.y+sel.h-1)}
 const st=[[x,y]];while(st.length){const [cx,cy]=st.pop();if(cx<bx0||cy<by0||cx>bx1||cy>by1)continue;const i=cy*w+cx;if(px[i]!==t)continue;
  px[i]=v;paintPix(i);st.push([cx+1,cy],[cx-1,cy],[cx,cy+1],[cx,cy-1])}}
function region(){return sel||{x:0,y:0,w:data.info.w,h:data.info.h}}
function forEachIn(r,f){const w=data.info.w;for(let y=r.y;y<r.y+r.h;y++)for(let x=r.x;x<r.x+r.w;x++)f(y*w+x,x,y)}
function needSel(){if(!sel){toast('Select an area first (Select tool, M).','warn');return false}return true}
function copySel(){if(!needSel())return false;const r=sel,w=data.info.w,out=new Uint8Array(r.w*r.h);
 for(let y=0;y<r.h;y++)out.set(data.px.subarray((r.y+y)*w+r.x,(r.y+y)*w+r.x+r.w),y*r.w);clip={w:r.w,h:r.h,px:out};updateUndo();return true}
function pasteClip(){if(!clip)return;const o=sel?{x:sel.x,y:sel.y}:(hover||{x:0,y:0});snapshot();
 for(let y=0;y<clip.h;y++)for(let x=0;x<clip.w;x++){const v=clip.px[y*clip.w+x];if(v<ncol())setPx(o.x+x,o.y+y,v)}
 sel={x:o.x,y:o.y,w:Math.min(clip.w,data.info.w-o.x),h:Math.min(clip.h,data.info.h-o.y)};commit()}
function clearSel(){if(!needSel())return;snapshot();forEachIn(sel,i=>{if(data.px[i]){data.px[i]=0;paintPix(i)}});commit()}
function flip(hz){if(!needSel())return;snapshot();const r=sel,w=data.info.w,src=data.px.slice();
 forEachIn(r,(i,x,y)=>{const sx=hz?r.x+r.w-1-(x-r.x):x,sy=hz?y:r.y+r.h-1-(y-r.y);data.px[i]=src[sy*w+sx];paintPix(i)});commit()}

/* ---------- mouse ---------- */
const cv=$('#cv');let drag=null;
function pos(e){const z=+$('#zoom').value,r=cv.getBoundingClientRect();return {x:Math.floor((e.clientX-r.left)/z),y:Math.floor((e.clientY-r.top)/z)}}
function inside(p){return data&&p.x>=0&&p.y>=0&&p.x<data.info.w&&p.y<data.info.h}
function selRect(a,b){let x0=Math.max(0,Math.min(a.x,b.x)),y0=Math.max(0,Math.min(a.y,b.y)),x1=Math.min(data.info.w-1,Math.max(a.x,b.x)),y1=Math.min(data.info.h-1,Math.max(a.y,b.y));
 if($('#snap').checked){x0&=~7;y0&=~7;x1|=7;y1|=7;x1=Math.min(x1,data.info.w-1);y1=Math.min(y1,data.info.h-1)}return {x:x0,y:y0,w:x1-x0+1,h:y1-y0+1}}
cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('pointerdown',e=>{if(!data)return;const p=pos(e);if(!inside(p))return;cv.setPointerCapture(e.pointerId);
 const right=e.button===2,v=right?sec:prim;
 if(e.altKey||tool==='picker'){const s=data.px[p.y*data.info.w+p.x];if(right)sec=s;else prim=s;renderSwatches();return}
 if(tool==='pencil'){snapshot();drag={kind:'pencil',v,last:p,changed:setPx(p.x,p.y,v)};draw()}
 else if(tool==='fill'){snapshot();flood(p.x,p.y,v);commit()}
 else if(tool==='select'){drag={kind:'select',a:p,moved:false};sel=$('#snap').checked?selRect(p,p):null;updateUndo();draw()}});
cv.addEventListener('pointermove',e=>{if(!data)return;const p=pos(e);
 if(inside(p)){hover=p;const t=Math.floor(p.y/8)*(data.info.w/8)+Math.floor(p.x/8);$('#st2').textContent=`x ${p.x} y ${p.y} · tile ${t} (0x${t.toString(16)}) · slot ${data.px[p.y*data.info.w+p.x]}`}
 else hover=null;
 if(drag&&drag.kind==='pencil'){line(drag.last.x,drag.last.y,Math.max(-1,Math.min(data.info.w,p.x)),Math.max(-1,Math.min(data.info.h,p.y)),drag.v);drag.last=p;drag.changed=true}
 if(drag&&drag.kind==='select'){if(p.x!==drag.a.x||p.y!==drag.a.y)drag.moved=true;if(drag.moved||$('#snap').checked)sel=selRect(drag.a,p);updateUndo()}
 draw()});
function endDrag(){if(!drag)return;if(drag.kind==='pencil'){const H=hist();const before=H.undo[H.undo.length-1];
  let same=before&&before.length===data.px.length;if(same)for(let i=0;i<before.length;i++)if(before[i]!==data.px[i]){same=false;break}
  if(same)H.undo.pop();else commit();updateUndo()}drag=null}
cv.addEventListener('pointerup',endDrag);cv.addEventListener('pointercancel',endDrag);
cv.addEventListener('pointerleave',()=>{hover=null;draw()});
$('#stage').addEventListener('scroll',draw);
$('#stage').addEventListener('wheel',e=>{if(!e.ctrlKey)return;e.preventDefault();zoomStep(e.deltaY<0?1:-1)},{passive:false});
function zoomStep(d){const s=$('#zoom'),i=Math.max(0,Math.min(s.options.length-1,s.selectedIndex+d));s.selectedIndex=i;store.set('#zoom',s.value);draw()}

/* ---------- tools & buttons ---------- */
function setTool(t){tool=t;document.querySelectorAll('.tool').forEach(b=>b.classList.toggle('on',b.dataset.tool===t));cv.className='t-'+t;store.set('tool',t);draw()}
document.querySelectorAll('.tool').forEach(b=>b.onclick=()=>setTool(b.dataset.tool));
$('#undo').onclick=undo;$('#redo').onclick=redo;$('#copy').onclick=copySel;$('#paste').onclick=pasteClip;
$('#flipH').onclick=()=>flip(true);$('#flipV').onclick=()=>flip(false);$('#clear').onclick=clearSel;
$('#ps').onclick=()=>{[prim,sec]=[sec,prim];renderSwatches()};
['#zoom','#grid','#pgrid','#nums'].forEach(s=>$(s).addEventListener('change',()=>{store.set(s,$(s).type==='checkbox'?$(s).checked:$(s).value);draw()}));
['#filltile','#snap'].forEach(s=>$(s).addEventListener('change',()=>store.set(s,$(s).checked)));
$('#trans').addEventListener('change',()=>{store.set('#trans',$('#trans').checked);buildImage()});
$('#palette').addEventListener('change',()=>{store.set('pal:'+cur,pal().name);buildImage()});
$('#q').addEventListener('input',renderList);

/* ---------- remap dialog ---------- */
let rmFrom=1,rmTo=2;
function slotPicker(el,get,set){el.innerHTML='';const P=pal(),n=ncol(),small=n>16;
 for(let i=0;i<n;i++){const d=document.createElement('div');d.className='sw'+(small?' small':'')+(i===get()?' on':'');d.style.background=P.colors[i]||'#f0f';if(!small)d.textContent=i;d.title='slot '+i;
  d.onclick=()=>{set(i);slotPicker(el,get,set);rmCount()};el.appendChild(d)}}
function rmCount(){const r=document.querySelector('input[name=rmScope]:checked').value==='sel'&&sel?sel:{x:0,y:0,w:data.info.w,h:data.info.h};
 let a=0,b=0;forEachIn(r,i=>{if(data.px[i]===rmFrom)a++;else if(data.px[i]===rmTo)b++});
 $('#rmCount').textContent=`${a} pixel(s) use slot ${rmFrom}, ${b} use slot ${rmTo} in this area.`}
function openRemap(){if(!data)return;rmFrom=prim;rmTo=sec===prim?(prim+1)%ncol():sec;
 $('#rmScopeSel').disabled=!sel;(sel?$('#rmScopeSel'):$('#rmScopeAll')).checked=true;
 slotPicker($('#rmFrom'),()=>rmFrom,v=>rmFrom=v);slotPicker($('#rmTo'),()=>rmTo,v=>rmTo=v);rmCount();$('#remapDlg').showModal()}
document.querySelectorAll('input[name=rmScope]').forEach(r=>r.onchange=rmCount);
$('#remap').onclick=openRemap;
$('#remapDlg').addEventListener('close',()=>{if($('#remapDlg').returnValue!=='ok'||rmFrom===rmTo)return;
 const swap=document.querySelector('input[name=rmMode]:checked').value==='swap';
 const r=document.querySelector('input[name=rmScope]:checked').value==='sel'&&sel?sel:{x:0,y:0,w:data.info.w,h:data.info.h};
 snapshot();let n=0;forEachIn(r,i=>{const v=data.px[i];if(v===rmFrom){data.px[i]=rmTo;paintPix(i);n++}else if(swap&&v===rmTo){data.px[i]=rmFrom;paintPix(i);n++}});
 if(!n){hist().undo.pop();updateUndo();toast('No pixels used those slots.','warn');return}commit();toast(`${n} pixel(s) remapped.`)});
$('#helpBtn').onclick=()=>$('#helpDlg').showModal();

/* ---------- keyboard ---------- */
document.addEventListener('keydown',e=>{if(e.target.matches('input[type=search],input[type=text],input[type=number],textarea')||document.querySelector('dialog[open]'))return;
 if(e.target.matches('select')){if(/^(Arrow|Page|Home|End|Enter| )/.test(e.key))return;e.target.blur()}
 const k=e.key,c=e.ctrlKey||e.metaKey;
 if(c&&(k==='z'||k==='Z')){e.preventDefault();e.shiftKey?redo():undo();return}
 if(c&&(k==='y'||k==='Y')){e.preventDefault();redo();return}
 if(c&&(k==='c'||k==='C')){e.preventDefault();copySel();return}
 if(c&&(k==='x'||k==='X')){e.preventDefault();if(copySel())clearSel();return}
 if(c&&(k==='v'||k==='V')){e.preventDefault();pasteClip();return}
 if(c&&(k==='s'||k==='S')){e.preventDefault();$('#save').click();return}
 if(c&&(k==='a'||k==='A')){e.preventDefault();sel={x:0,y:0,w:data.info.w,h:data.info.h};updateUndo();draw();return}
 if(c)return;
 const lk=k.toLowerCase();
 if(lk==='b')setTool('pencil');else if(lk==='g')setTool('fill');else if(lk==='i')setTool('picker');else if(lk==='m')setTool('select');
 else if(lk==='x'){[prim,sec]=[sec,prim];renderSwatches()}
 else if(lk==='h'&&sel)flip(true);else if(lk==='v'&&sel)flip(false);
 else if(lk==='r')openRemap();
 else if(k==='Delete'||k==='Backspace'){if(sel)clearSel()}
 else if(k==='Escape'){sel=null;updateUndo();draw()}
 else if(k==='['){prim=(prim+ncol()-1)%ncol();renderSwatches()}else if(k===']'){prim=(prim+1)%ncol();renderSwatches()}
 else if(k==='+'||k==='=')zoomStep(1);else if(k==='-')zoomStep(-1);
 else{const m=/^Digit(\d)$/.exec(e.code);if(m){const v=+m[1];if(v<ncol()){if(e.shiftKey)sec=v;else prim=v;renderSwatches()}}}});

/* ---------- file actions ---------- */
$('#export').onclick=async()=>{if(!cur)return;await flush();const a=document.createElement('a');a.href=`/api/export?id=${encodeURIComponent(cur)}&palette=${encodeURIComponent(pal().name)}`;a.download=cur+'.png';document.body.appendChild(a);a.click();a.remove()};
$('#import').onclick=()=>$('#file').click();
$('#file').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(f)await doImport(f)};
async function doImport(f){try{await flush();const before=data.px.slice();
 const r=await api(`/api/import?id=${encodeURIComponent(cur)}&palette=${encodeURIComponent(pal().name)}`,{method:'POST',body:await f.arrayBuffer()});
 const H=hist();H.undo.push(before);H.redo.length=0;
 const l=await api('/api/list');setDirty(l.dirty);await select(cur);
 toast(`Imported ${f.name}: ${r.changed_tiles} tile(s) changed (${r.mode==='indexed'?'indexed PNG':'matched by color'}).`+(r.warnings.length?'\n\n'+r.warnings.join('\n'):'')+(r.dirty?'\n\nClick “Save to game” to write it.':''),r.warnings.length?'warn':'')}
 catch(err){toast('Import failed: '+err.message,'err')}}
const stage=$('#stage');stage.addEventListener('dragover',e=>{e.preventDefault();stage.classList.add('drop')});
stage.addEventListener('dragleave',()=>stage.classList.remove('drop'));
stage.addEventListener('drop',e=>{e.preventDefault();stage.classList.remove('drop');const f=e.dataTransfer.files[0];if(f&&cur)doImport(f)});
$('#revert').onclick=async()=>{if(!cur||!DIRTY.has(cur))return;await flush();const before=data.px.slice();await api('/api/revert?id='+encodeURIComponent(cur),{method:'POST'});
 const H=hist();H.undo.push(before);H.redo.length=0;const l=await api('/api/list');setDirty(l.dirty);await select(cur);toast('Reverted. Undo (Ctrl+Z) brings your edits back.')};
$('#save').onclick=async()=>{if($('#save').disabled)return;try{await flush();const r=await api('/api/save',{method:'POST'});setDirty([]);draw();toast(r.message+(r.backups&&r.backups.length?'\nBackups: '+r.backups.join(', '):''))}catch(e){toast('Save failed: '+e.message,'err')}};
$('#exportAll').onclick=async()=>{try{await flush();const r=await api('/api/export-all?open=1',{method:'POST'});toast(r.message)}catch(e){toast(e.message,'err')}};
$('#importAll').onclick=async()=>{try{await flush();const r=await api('/api/import-all',{method:'POST'});setDirty(r.dirty);HIST.clear();if(cur)await select(cur);toast(r.message+(r.log.length?'\n\n'+r.log.join('\n'):''),'')}catch(e){toast(e.message,'err')}};

document.querySelectorAll('.bar select,.bar input[type=checkbox],.bar button,.edit button').forEach(el=>el.addEventListener(el.matches('select')?'change':'click',()=>setTimeout(()=>el.blur(),0)));
/* ---------- startup ---------- */
$('#zoom').value=store.get('#zoom','4');$('#grid').checked=store.get('#grid',true);$('#pgrid').checked=store.get('#pgrid',true);$('#nums').checked=store.get('#nums',false);
$('#trans').checked=store.get('#trans',true);$('#filltile').checked=store.get('#filltile',true);$('#snap').checked=store.get('#snap',false);setTool(store.get('tool','pencil'));
window.addEventListener('beforeunload',e=>{if(pushTimer){clearTimeout(pushTimer);pushTimer=null;navigator.sendBeacon('/api/pixels?id='+encodeURIComponent(cur),new Blob([data.px]))}
 if(DIRTY.size){e.preventDefault();e.returnValue=''}});
window.addEventListener('pagehide',()=>navigator.sendBeacon('/api/bye',''));
setInterval(()=>fetch('/api/ping').catch(()=>{}),5000);
load().catch(e=>toast('Failed to load: '+e.message,'err'));
</script></body></html>
"""

# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------

def show_error(msg):
    try:
        with open(os.path.join(app_data_dir(), "error.log"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception:
        pass
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, msg, "Zelda3 Texture Tool", 0x10)
            return
        except Exception:
            pass
    print(msg, file=sys.stderr)


def main(argv):
    game = os.path.dirname(TOOL_DIR)
    args = []
    palette = None
    port = 0
    no_browser = False
    windowed = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--game":
            game = argv[i + 1]; i += 2; continue
        if a == "--palette":
            palette = argv[i + 1]; i += 2; continue
        if a == "--port":
            port = int(argv[i + 1]); i += 2; continue
        if a == "--no-browser":
            no_browser = True; i += 1; continue
        if a == "--windowed":
            windowed = True; i += 1; continue
        if a in ("-h", "--help"):
            print(__doc__); return 0
        args.append(a); i += 1
    cmd = args[0] if args else "gui"
    try:
        proj = Project(game)
    except SystemExit as e:
        if windowed:
            show_error(str(e)); return 2
        raise
    except Exception as e:
        if windowed:
            show_error("Could not load the game files in %s:\n\n%s: %s" % (game, type(e).__name__, e)); return 2
        raise
    export_dir = os.path.join(proj.game_dir, "texture_tool", "export")
    if cmd == "gui":
        run_server(proj, port, not no_browser, exit_when_closed=windowed)
    elif cmd == "list":
        for t in proj.textures:
            print("%-10s %-4s %4dx%-4d %s%s" % (t.id, "%dbpp" % t.bpp, t.w, t.h, t.label, ("  - " + t.note) if t.note else ""))
    elif cmd == "export-all":
        d = args[1] if len(args) > 1 else export_dir
        print("Exported %d textures to %s" % (export_all(proj, d), d))
    elif cmd == "import-all":
        d = args[1] if len(args) > 1 else export_dir
        n = import_all(proj, d)
        if n:
            r = proj.save()
            print(r["message"], "Backups:", ", ".join(r.get("backups", [])))
        else:
            print("No changes found in %s" % d)
    elif cmd == "export":
        tid, out = args[1], args[2]
        open(out, "wb").write(proj.export_png(tid, palette))
        print("Wrote", out)
    elif cmd == "import":
        tid, src = args[1], args[2]
        rep = proj.import_png(tid, open(src, "rb").read(), palette)
        for w in rep["warnings"]:
            print("!", w)
        if rep["dirty"]:
            r = proj.save()
            print("%d tile(s) changed. %s" % (rep["changed_tiles"], r["message"]))
        else:
            print("No changes.")
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    if "--windowed" in sys.argv:
        try:
            sys.exit(main(sys.argv[1:]))
        except Exception:
            import traceback
            show_error("Unexpected error:\n\n" + traceback.format_exc())
            sys.exit(2)
    sys.exit(main(sys.argv[1:]))
